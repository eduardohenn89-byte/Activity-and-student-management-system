# Activity-and-student-management-system
Simple activity and student management system, you can register and remove students and activities

The main file that must be executed is SistemaGestaoSwing.java

Important!!!
JDK Java must be installed on your machine



To compile the code, use the following command in the terminal (I'm using VS CODE with the Extension Pack for Java extension) 

To compile
javac SistemaGestaoSwing.java

Must be done in all CLASSES


To execute (only in the SistemaGestaoSwing.java file)
javaSwingGestaoSystem

Done! My code is running !!
